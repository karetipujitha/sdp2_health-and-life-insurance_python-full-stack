from django.contrib import admin
from .models import Plans
admin.site.register(Plans)
from .models import Applied
admin.site.register(Applied)
from .models import Queries
admin.site.register(Queries)
# Register your models here.
