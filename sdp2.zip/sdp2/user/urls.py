from django.contrib import admin
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import include, path
from .import views

urlpatterns = [
    path('',views.index,name="user-Index"),
    path('login/', views.login,name='user-Login'),
    path('signup/', views.signup,name='user-Signup'),
    path('home/', views.home,name='user-Home'),
    path('index/', views.index,name='user-Home'),
    path('plans/', views.plans,name='user-Home'),
    path('viewPlan/', views.viewPlan,name='user-Home'),
    path('applyPlan/', views.applyPlan,name='user-Home'),
    path('applyPlan/', views.applyPlan,name='user-Home'),
    path('myPlans/', views.myPlans,name='user-Home'),
    path('logout/', views.logout,name='user-Home'),
    path('health/', views.health,name='user-Home'),
    path('life/', views.life,name='user-Home'),
    path('account/', views.account,name='user-Home'),
    path('editAccount', views.editAccount,name='user-Home'),
    path('email', views.email,name='user-Home'),
    path('alogin', views.alogin,name='user-Home'),
    path('viewApp', views.viewApp,name='user-Home'),
    path('Contact', views.Contact,name='user-Home')
]
