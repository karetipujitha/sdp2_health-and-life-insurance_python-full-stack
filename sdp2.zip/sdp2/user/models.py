from django.db import models

# Create your models here.
class Plans(models.Model):
    name = models.CharField(max_length=100)
    img = models.ImageField(upload_to='pics')
    prem = models.CharField(max_length=50)
    age = models.TextField()
    cov = models.CharField(max_length=20)
    t1 = models.TextField()
    t2 = models.TextField()
    t3 = models.TextField()
    cat = models.CharField(max_length=20)

class Applied(models.Model):
    category = models.CharField(max_length=20)
    pname = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    dob = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)
    email = models.CharField(max_length=50)
    pin = models.CharField(max_length=20)
    city = models.CharField(max_length=20)
    state = models.CharField(max_length=20)
    country = models.CharField(max_length=20)
    date = models.CharField(max_length=20)
    nname = models.CharField(max_length=20)
    nage = models.CharField(max_length=20)
    iname = models.CharField(max_length=20)
    idob = models.CharField(max_length=20)
    iheight = models.CharField(max_length=20)
    iweight = models.CharField(max_length=20)
    irel = models.CharField(max_length=20)

class Queries(models.Model):
    username = models.CharField(max_length=100)
    email = models.CharField(max_length=50)
    subject = models.TextField()
