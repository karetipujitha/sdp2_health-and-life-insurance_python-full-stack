from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import Plans
from .models import Applied,Queries
from django.core.mail import send_mail
from django.template import RequestContext
from django.template.context_processors import csrf
from django.contrib.auth import authenticate, login

# Create your views here.

def home(request):
    return render(request, 'user/home.html', {'title' : 'Home'})

def Contact(request):
    if request.method == 'POST':
        username=request.POST['username']
        subject=request.POST['subject']
        email=request.POST['email']
        queries=Queries(username=username,email=email,subject=subject)
        queries.save();
        return render(request, 'user/editAccount.html', {'title': 'Home'})
    return render(request, 'user/Contact.html', {'title' : 'Home'})

def alogin(request):
    app = Applied.objects.all()
    return render(request, 'user/alogin.html', {'app' : app})

def viewApp(request):
    return render(request, 'user/viewApp.html')

def email(request):
    if request.method=='POST':
        email=request.POST['email']
        send_mail('Payment Alert', 'hello dear customer, your Premium date is coming soon. Please pay your premium in time', 'ppponlineinsurance@gmail.com', [email], fail_silently=False)
        return render(request,'user/viewApp.html')
    return render(request, 'user/email.html')


def applyPlan(request):
    if request.method == 'POST':
        category=request.POST['category']
        pname=request.POST['pname']
        username=request.POST['username']
        dob=request.POST['dob']
        phone = request.POST['phone']
        email=request.POST['email']
        pin = request.POST['pin']
        city = request.POST['city']
        state = request.POST['state']
        country = request.POST['country']
        date = request.POST['date']
        nname = request.POST['nname']
        nage = request.POST['nage']
        iname = request.POST['iname']
        idob = request.POST['idob']
        iheight = request.POST['iheight']
        iweight = request.POST['iweight']
        irel = request.POST['irel']
        applied=Applied(category=category,pname=pname,username=username,dob=dob,phone=phone,email=email,pin=pin,city=city,state=state,country=country,date=date,nname=nname,nage=nage,iname=iname,idob=idob,iheight=iheight,iweight=iweight,irel=irel)
        applied.save();
        messages.info(request, 'Policy applied successfully')
        return render(request, 'user/plans.html')
    return render(request, 'user/applyPlan.html', {'title' : 'Home'})

def index(request):
    return render(request, 'user/index.html', {'title' : 'Home'})

def plans(request):
    if request.method == 'POST':
        id=int(request.POST['id'])
        plans = Plans.objects.all()
        return render(request, 'user/viewPlan.html',{'id':id,'plans':plans})
    plans = Plans.objects.all()
    return render(request, 'user/plans.html', {'plans' : plans})
def health(request):
    if request.method == 'POST':
        id=int(request.POST['id'])
        plans = Plans.objects.all()
        return render(request, 'user/viewPlan.html',{'id':id,'plans':plans})
    plans = Plans.objects.all()
    return render(request, 'user/health.html', {'plans' : plans})
def life(request):
    if request.method == 'POST':
        id=int(request.POST['id'])
        plans = Plans.objects.all()
        return render(request, 'user/viewPlan.html',{'id':id,'plans':plans})
    plans = Plans.objects.all()
    return render(request, 'user/life.html', {'plans' : plans})

def viewPlan(request):
    plans = Plans.objects.all()
    return render(request, 'user/viewPlan.html', {'plans' : plans})

def myPlans(request):
    app = Applied.objects.all()
    plans = Plans.objects.all()
    return render(request, 'user/myPlans.html', {'app' : app,'plans':plans})

def account(request):
    if request.method == 'POST':
        return render(request, 'user/editAccount.html')
    return render(request, 'user/account.html')
def editAccount(request):
    return render(request, 'user/editAccount.html')

def apply(request):
    if request.method == 'POST':
        return render(request, 'user/applyPlan.html')

def login(request):
    if request.method == 'POST':
        username=request.POST['username']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if username=="priya" and password == "1234":
            app = Applied.objects.all()
            return render(request,'user/alogin.html',{'app' : app})
        elif user is not None:
            auth.login(request, user)
            return render(request, 'user/home.html')
        else:
            messages.info(request,'Invalid Credentials')
            return render(request, 'user/login.html', {'title': 'Login'})
    else:
        return render(request, 'user/login.html', {'title' : 'Login'})

def logout(request):
    auth.logout(request)
    return redirect('/')

def signup(request):
    if request.method == 'POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
        if User.objects.filter(username=username).exists():
            messages.info(request,'Username Taken')
        elif password1!=password2:
            messages.info(request,'Passwords are not matching')
        else:
            user=User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
            user.save();
            messages.info(request, 'Account is created successfully')
            return render(request, 'user/login.html')
    return render(request, 'user/signup.html')